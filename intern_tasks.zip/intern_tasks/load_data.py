from qgis.core import QgsRasterLayer, QgsSingleBandPseudoColorRenderer, QgsColorRampShader, QgsRasterShader
from PyQt5.QtGui import QColor

image_path = '/Users/amirthavarshini/Downloads/intern_tasks/seqana_gis_solutions_engineering_working_student_challenge_data 2/covariates/open_land_map_soil_ph.tif'
layer_name = 'Open Land Map Soil pH'

layer = QgsRasterLayer(image_path, layer_name)
if not layer.isValid():
    print("Layer failed to load!")
else:
    QgsProject.instance().addMapLayer(layer)

# Assuming there are 6 bands (0 to 5), you can adjust the range if needed
num_bands = 6
band_colors = ['#FF0000', '#00FF00', '#0000FF', '#FFFF00', '#FF00FF', '#00FFFF']  # You can adjust the colors here

for band_index in range(num_bands):
    renderer = QgsSingleBandPseudoColorRenderer(layer.dataProvider(), band_index + 1)
    color_ramp = QgsColorRampShader()
    color_ramp.setColorRampType(QgsColorRampShader.Interpolated)
    
    # Define color stops for each band
    color_ramp_items = []
    for stop in range(0, 10):  # You can adjust the number of color stops if needed
        value = stop / 10.0
        color = QColor(band_colors[band_index])
        color_ramp_items.append(QgsColorRampShader.ColorRampItem(value, color))
    color_ramp.setColorRampItemList(color_ramp_items)
    
    shader = QgsRasterShader()
    shader.setRasterShaderFunction(color_ramp)
    renderer.setShader(shader)
    
    layer.setRenderer(renderer)
    layer.triggerRepaint()
